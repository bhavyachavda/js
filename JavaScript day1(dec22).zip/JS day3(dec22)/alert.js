//alert( 'Hello, world!' );

//alert('Hello'); alert('World');

//alert('Hello');
//alert('World');

//alert(3 + 1 + 2);

//alert("Hello");
//[1, 2].forEach(alert);

//let message = 'Hello!';
//alert(message);

//let message;
//message = 'Hello!';
//message = 'World!'; // value changed
//alert(message);

/*let hello = 'Hello world!';
let message;
message = hello;
alert(hello); 
alert(message); */

/*let $=1;
let _=2;
alert($+_);*/

/*const myBirthday = '18.04.1982';
myBirthday = '01.01.2001';
*/

/*const COLOR_RED = "#F00";
const COLOR_GREEN = "#0F0";
const COLOR_BLUE = "#00F";
const COLOR_ORANGE = "#FF7F00";

let color = COLOR_ORANGE;
alert(color);*/

/*let name = "Bhavya";
// embed a variable
alert( `Hello, ${name}!` ); 

// embed an expression
alert( `the result is ${1 + 2}` ); */

/*let isGreater = 4 > 1;

alert( isGreater );*/

//alert( "the result is ${1 + 2}" );

//let age;
//alert(age)

/*let value = true;
alert(typeof value); // boolean

value = String(value); // now value is a string "true"
alert(typeof value); // string
*/

/*let str = "123";
alert(typeof str); // string

let num = Number(str); // becomes a number 123

alert(typeof num); // number
*/

/*let x = 1;
x = -x;
alert( x );*/

/*alert( 5 % 2 ); 
alert( 8 % 3 ); 
alert( 8 % 4 );
*/

/*alert( 2 ** 2 ); 
alert( 2 ** 3 ); 
alert( 2 ** 4 );*/

//let s = "my" + "string";
//alert(s);

/*let a = 1;
let b = 2;
let c = 3 - (a = b + 1);
alert( a ); // 3
alert( c ); */

/*let counter = 2;
counter++;       
alert( counter );*/

/*let counter=2;
counter--;
alert(counter);*/

//let a = (1 + 2, 3 + 4);
//alert( a );

/*alert( 2 > 1 );  
alert( 2 == 1 ); 
alert( 2 != 1 );*/

//alert( 0 === false ); 

//alert(null=== undefined);

//alert(null==undefined);

/*let year = prompt('In which year messi won the fifa world cup 2022?', '');
if (year == 2022) alert( 'You are right!' );
*/

/*let year = prompt('In which year messi won the fifa world cup 2022?', '');
if (year == 2022) {
  alert( 'You guessed it right!' );
} else {
  alert( 'How can you be so wrong?' ); 
}*/

/*let year = prompt('In which year messi won the fifa world cup 2022?', '');
if (year < 2022) {
  alert( 'Too early...' );
} else if (year > 2022) {
  alert( 'Too late' );
} else {
  alert( 'Exactly!' );
}*/

 //Conditional operator

/*let Allowed;
let age = prompt('How old are you?', '');
if (age > 18) {
  Allowed = true;
} else {
  Allowed = false;
}
alert(Allowed);*/

//Multiple '?'

/*let age=prompt('age?',18);
let message=(age<3)? 'Hi, baby!':
    (age<18)? 'Hello!' :
    (age<100)? 'Greetings!' :
    'What an unusal age!';
alert(message);*/

//Logical operators
//OR ||
/*alert(true||true);
alert(false||false);
alert(true||false);
alert(false||true);
*/

/*let hour=12;
let isWeekend = true;
if(hour<10 || hour>18 || isWeekend)
{
    alert('The office is closed.');
}*/

//&& operator
/*alert( true && true );   
alert( false && true );  
alert( true && false );  
alert( false && false ); 
*/

/*
let hour=12;
let minute=32;
if(hour==12 && minute==32)
{
    alert('The time is 12:32')
}*/

//!(NOT)
//alert(!true);
//alert(!0);

//while loop
// let i = 0;
// while (i < 3) 
// { 
//   alert( i );
//   i++;
// }

//Do while loop
// let i=0;
// do{
//     alert(i);
//     i++;
// }while(i<3);

//for loop
// for(let i=0;i<5;i++)
// {
//     alert(i);
// }

//breaking the loop
// let sum=0;
// while(true)
// {
//     let value = +prompt("Enter the number",'');
//     if(!value) break;
//     sum +=value;
// }
// alert('Sum:' + sum);

//continue the next iteration
// for(let i=0;i<10;i++)
// {
//     if(i%2)
//     {
//         alert(i);
//     }
// }

//switch case
// let a=2+2;
// switch(a){
//     case 3:
//     alert('To small');
//     break;
//     case 4:
//         alert('Exactly');
//         break;
//     case 5:
//         alert('Too big');
//         break;
//     default:
//         alert("I dont Know such values");
// }

//Function Declaration
// function showmessage(){
//     alert("I am bhavya chavda");
// }
// showmessage();
// showmessage();

//local variables
// function showmessage(){
//     let message="Hello i am bhavya";
//     alert(message);
// }
// showmessage();
// alert(message);

//outer variables
// let username='Bhavya';
// function showmessage()
// {
//     username='Bob';
//     let message='Hello, ' + username;
//     alert(message);
// }
// alert(username);
// showmessage();
// alert(username);

//returning value
// function sum(a,b)
// {
//     return a+b;
// }
// let result=sum(5,5);
// alert(result);

//Arrow function
// let sum = (a, b) => a + b;

// alert( sum(1, 2) ); 

let age = prompt("What is your age?", 18);

let welcome = (age < 18) ?
  () => alert('Hello!') :
  () => alert("Greetings!");

welcome();