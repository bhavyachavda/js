const func = () => {
    window.open(
      "popup2.htm","","left=100,top=100,width=400,height=200");
  };
  
  const end = () => {
    window.close();
  };